import argparse

def build_out_arr(file):
	file_arr = []
	for line in file.readlines():
		line_lst = line.translate(None, '\n|[|]').split(';')
		line_set = set(ele.strip() for ele in line_lst if ele.strip() != '')
		file_arr.append(line_set)
	return file_arr


if __name__ == '__main__':
	parser = argparse.ArgumentParser()
	parser.add_argument('path_expected', type=str)
	parser.add_argument('path_actual', type=str)
	args = parser.parse_args()

	with open(args.path_expected, 'r') as f:
		expected = build_out_arr(f)

	with open(args.path_actual, 'r') as f:
		actual = build_out_arr(f)

	try:
		assert(len(expected) == len(actual))
	except AssertionError:
		raise AssertionError(
			"EXPECTED AND ACTUAL FILE LENGTHS NOT EQUAL\n \tEXPECTED LENGTH: {}\n \tACTUAL LENGTH: {}".format(
				len(expected), len(actual)))

	for i in range(len(expected)):
		try:
			assert(expected[i] == actual[i])
		except AssertionError:
			print('MISMATCH ON LINE: {}'.format(i+1))
			print('\tEXPECTED: {}'.format(expected[i]))
			print('\tACTUAL: {}\n'.format(actual[i]))