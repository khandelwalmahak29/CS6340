#!/usr/bin/env python3

import argparse
import sys

def canonicalize_set(line):
    """
    If argument line is an instruction set, sort the instructions by number.
    """

    line = line.strip()
    
    # Check for instruction set.
    index = line.find('[')
    if index == 0:

        # Remove square brackets.
        line = line[index+1:line.rfind(']')].strip()
        
        # Split instructions.
        inst_dict = {}
        for inst in line.split(';'):
            parts = [s.strip() for s in inst.strip().split('=')]
            if len(parts) > 1:
                inst_dict[parts[0]] = parts[1]

        # Recreate sorted instruction set.
        line = ''
        for k in sorted(inst_dict.keys()):
            line += '{0} = {1}; '.format(k,inst_dict[k])

    return line

if __name__ == '__main__':

    # Handle command line arguments.
    parser = argparse.ArgumentParser(description='Compare Dataflow analysis files')
    parser.add_argument('file1')
    parser.add_argument('file2')

    args = parser.parse_args()

    # Read lines from file1.
    with open(args.file1, 'r') as fid:
        list1 = fid.readlines()

    # Read lines from file2.
    with open(args.file2, 'r') as fid:
        list2 = fid.readlines()

    # Line count mismatch indicates serious problem.
    if len(list1) != len(list2):
        sys.exit('*** Line count mismatch!')

    # Compare line by line.
    for num,lines in enumerate(zip(list1,list2)):

        # Canonicalize instruction set lines.
        line1 = canonicalize_set(lines[0])
        line2 = canonicalize_set(lines[1])

        # Compare lines.
        if line1 != line2:
            print('*** Difference encountered at line {0}'.format(num+1), file=sys.stderr)
            print('< ' + line1, file=sys.stderr)
            print('---', file=sys.stderr)
            print('> ' + line2, file=sys.stderr)
            sys.exit(1)
