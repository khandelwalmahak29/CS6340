#!/usr/bin/env python3

import sys

def dynamicDiff(l1, l2):
    """Diff 2 lines that contain strings that look like arrays but separated
    by semicolons. Print diff to the screen.
    """
    # Remove the square brackets and trailing/leading whitespace.
    # Strip by semicolon, then remove any trailing/leading whitespace again.
    cleaned1 = [p.strip() for p in l1.strip('[]').strip().split(';')]
    cleaned2 = [p.strip() for p in l2.strip('[]').strip().split(';')]

    equal = True
    if len(cleaned1) != len(cleaned2):
        equal = False
    else:
        # Since the size is the same, we should be able to sort and compare.
        for i in zip(sorted(cleaned1), sorted(cleaned2)):
            #print(i)
            if i[0] != i[1]:
                equal = False
                print('{} IS NOT EQUAL TO {}'.format(i[0], i[1]))

    # Print line diff.
    if not equal:
        print('-%s' % l1)
        print('+%s' % l2)

def diff(f1, f2):
    with open(f1, 'r') as f:
        f1Lines = [l.strip() for l in f.readlines()]

    with open(f2, 'r') as f:
        f2Lines = [l.strip() for l in f.readlines()]

    if len(f1Lines) != len(f2Lines):
        print('The two files have unequal lengths!')
        return

    for l in zip(f1Lines, f2Lines):
        #print(l)
        if l[0].startswith('['):
            dynamicDiff(l[0], l[1])
        elif l[0] != l[1]:
            print('-%s' % l[0])
            print('+%s' % l[1])

if __name__ == '__main__':
    if not len(sys.argv) == 3:
        print('Usage: diff.py <f1> <f2>')
        sys.exit(1)

    diff (sys.argv[1], sys.argv[2])
