int main() {
    int a = 1, b = 4, c = 7;
    b = a*c;
    a = b++;
    for(a = 2; a < 10; a++) {
        c = b + c;
        b = a * a;
        while(b > 10) {
            if (b > c) {
                c++;
                if(c>30){
                    c -= 3;
                }
            }
            else {
                b--;
            }
        }
        for(int i = c-b; i>2; i--) {
            b = b + a;
        }
    }

    int d = a + b + c;
}