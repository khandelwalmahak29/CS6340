int main() {
    int z = 0;
    int y = 4;
    int x = 2;
    if (y != x)
        z = y;
    else
        z = y*y;
    x = z;
}
