#!/bin/bash
#author: Raul Viera (rviera6)

DIFF_UTILS=diff_utils
TEST_OUT_DIR=test_out

function analyze() {
	ANALYSIS=$1
	MAIN_DIR=$2

	mkdir -p $TEST_OUT_DIR/$MAIN_DIR 
	echo "----- $ANALYSIS Analysis -----"
	
	for f in $MAIN_DIR/*.c; do
		TEST_FILE="${f%.*}"
		TEST_OUT_FILE=$TEST_OUT_DIR/${TEST_FILE}_$ANALYSIS.out
		TEST_EXP_FILE=${TEST_FILE}_$ANALYSIS

		echo "-----$TEST_FILE-----"

		echo "Generating LLVM bitcode for $TEST_FILE..."
	        clang -emit-llvm $TEST_FILE.c -c -o $TEST_FILE.bc

		echo "Running $ANALYSIS Analysis on $TEST_FILE..."
		opt -load build/Dataflow/libDataflowPass.so -$ANALYSIS < $TEST_FILE.bc > /dev/null 2> $TEST_OUT_FILE || exit 1

		echo "Comparing output vs expected files for $TEST_FILE with diff.py..."
		./$DIFF_UTILS/diff.py $TEST_OUT_FILE $TEST_EXP_FILE || exit 1 

		echo "Comparing output vs expected files for $TEST_FILE with check_same.py..."
		python $DIFF_UTILS/check_same.py $TEST_EXP_FILE $TEST_OUT_FILE || exit 1

		echo "Comparing output vs expected files for $TEST_FILE with df_diff.py..."
		./$DIFF_UTILS/df_diff.py $TEST_OUT_FILE $TEST_EXP_FILE || exit 1

		echo "!!!!! $ANALYSIS analysis test passed for $TEST_FILE !!!!!"
	done
}


function main() {
	echo "Analysing example files..."
	analyze "ReachDef" "example"
	analyze "Liveness" "example"

	echo "Analysing piazza files..."
	analyze "ReachDef" "piazza_tests"
	analyze "Liveness" "piazza_tests"

	echo "----- PASSED ALL TEST! -----"
}

main
