int main() {
  int x = 0;
  int y = x;
  int z = y / x; // Divide by zero
  return 0;
}
